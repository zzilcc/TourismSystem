<!DOCTYPE HTML>
<html>
<head>
	<title>About me</title>
		<meta name="keywords" content="Introduction"/>
		<meta http-equiv="content-type" content="text/html;charset=utf-8"/>
		<?php include("header.php") ?>
	</head>
  <body>
	<div class="container">
	<?php include("menu.php"); ?>

<div class="row">
<div class="col-md-2">
	<?php include("vmenu.php"); ?>
</div>
<div class="col-md-10">

<div class="well well-lg">
<p>This site is provided by the front desk HTML+CSS, PHP+MySQL	building in the background.
<p>Producer Huang Ziqian, Ma Qian Have a BUG please contact 564123079@QQ.com
</div>

</div>
</div>

<?php include("footer.php"); ?>
	</body>
</html>
