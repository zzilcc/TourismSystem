<script src="js/bootstrap.min.js"></script>
<script src="js/material.js"></script>
<script src="js/ripples.min.js"></script>
<script>
  $.material.init();
</script>
