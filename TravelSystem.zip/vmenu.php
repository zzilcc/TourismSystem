<div class="btn-group-vertical">
     <a class="btn btn-raised" href="sceneinformation.php"><i class="material-icons">account_balance</i> Scene information</a>
		 <a class="btn btn-raised" href="customertraffic.php"><i class="material-icons">group</i> customer traffic</a>
		 <a class="btn btn-raised" href="schedule.php"><i class="material-icons">event_available</i> Schedule</a>
		 <a class="btn btn-raised" href="newestscene.php"><i class="material-icons">fiber_new</i> Customer traffic</a>
		 <a class="btn btn-raised" href="add.php"><i class="material-icons">add</i> Add News</a>
     <a class="btn btn-raised" href="about.php"><i class="material-icons">people</i> About Us</a>
</div>
